package graphics;

import main.MainFrame;

public class SettingsPanel extends GenericPanel {
	private MainFrame frame;
	
	public SettingsPanel(MainFrame frame) {
		this.frame = frame;
	}

}
