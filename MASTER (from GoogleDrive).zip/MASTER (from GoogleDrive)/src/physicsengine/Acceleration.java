package physicsengine;

import utils.Vector;

public class Acceleration extends Vector{
	
	public Acceleration(double x, double y, double z){
		super(x,y,z);
	}
}
